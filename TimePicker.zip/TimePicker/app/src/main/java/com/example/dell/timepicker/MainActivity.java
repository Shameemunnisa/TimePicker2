package com.example.dell.timepicker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    TimePicker tp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tp=findViewById(R.id.time);
        tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener()
        {
            @Override
            public void onTimeChanged(TimePicker view,
                                      int hourOfDay, int minute)
            {
                Toast.makeText(MainActivity.this,
                        "The time is"+hourOfDay+":"+minute,
                        Toast.LENGTH_SHORT).show();

            }
        });
    }
}
